<?php
/*
*@send response
*Хелпер отправки запросов
*Принимает заголовок в виде строки и запрос в виде ассоциативного массива
*Происходит настройка статуса ответа, заголовков и тела
*/
namespace app\helpers;
use Yii;


class sendResponse{

    public static function send($code, $header, $body){
        Yii::$app->response->statusCode = 501;
        $headers = Yii::$app->response->headers;
        $response = Yii::$app->response;
        $response->format = \yii\web\Response::FORMAT_JSON;
        if(isset($header, $body)){
            Yii::$app->response->statusCode = $code;
            $headers->add('status',$header);
            $response->data = $body;
        }
        else{
            $headers->add('status', 'bad request');
            $response->data = ['error' => 'error'];
        }
        //yii\web\Response::send();
        
    }
}