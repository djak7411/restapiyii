<?php
namespace app\helpers;
use Yii;

use app\helpers\sendResponse;
class checkToken{
    public static function checkToken(){
            $headers = getallheaders();
                if(!isset($headers['authorization']) || !$this->db->checkToken(str_replace('Bearer ','', $headers['authorization']))){
                        sendResponse::send(400, 'Unauthorized', ['message' => 'Unauthorized']);
                    } 
        }
}