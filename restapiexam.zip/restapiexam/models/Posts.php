<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "posts".
 *
 * @property int $id
 * @property string $title
 * @property string $datetime
 * @property string $anons
 * @property string $text
 * @property double $rating
 * @property string $image
 * @property int $sum_rating
 *
 * @property Comments[] $comments
 */
class Posts extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'posts';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['title', 'datetime', 'anons', 'text', 'rating', 'image', 'sum_rating'], 'required'],
            [['datetime'], 'safe'],
            [['rating'], 'number'],
            [['sum_rating'], 'integer'],
            [['title', 'anons', 'text', 'image'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'datetime' => 'Datetime',
            'anons' => 'Anons',
            'text' => 'Text',
            'rating' => 'Rating',
            'image' => 'Image',
            'sum_rating' => 'Sum Rating',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getComments()
    {
        return $this->hasMany(Comments::className(), ['post' => 'id']);
    }
}
