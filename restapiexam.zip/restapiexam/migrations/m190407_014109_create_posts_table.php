<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%posts}}`.
 */
class m190407_014109_create_posts_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%posts}}', [
            'id' => $this->primaryKey(),
            'title' => $this->string()->notNull(),
            'datetime' => $this->datetime()->notNull(),
            'anons' => $this->string()->notNull(),
            'text' => $this->string()->notNull(),
            'rating' => $this->float()->notNull(),
            'image' => $this->string()->notNull(),
            'sum_rating' => $this->integer()->notNull(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%posts}}');
    }
}
