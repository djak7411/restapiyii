<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%comments}}`.
 * Has foreign keys to the tables:
 *
 * - `{{%posts}}`
 * - `{{%admin}}`
 */
class m190407_014649_create_comments_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%comments}}', [
            'id' => $this->primaryKey(),
            'post' => $this->integer()->notNull(),
            'datetime' => $this->datetime()->notNull(),
            'author' => $this->integer()->notNull(),
            'comment' => $this->string()->notNull(),
        ]);

        // creates index for column `post`
        $this->createIndex(
            '{{%idx-comments-post}}',
            '{{%comments}}',
            'post'
        );

        // add foreign key for table `{{%posts}}`
        $this->addForeignKey(
            '{{%fk-comments-post}}',
            '{{%comments}}',
            'post',
            '{{%posts}}',
            'id',
            'CASCADE'
        );

        // creates index for column `author`
        $this->createIndex(
            '{{%idx-comments-author}}',
            '{{%comments}}',
            'author'
        );

        // add foreign key for table `{{%admin}}`
        $this->addForeignKey(
            '{{%fk-comments-author}}',
            '{{%comments}}',
            'author',
            '{{%admin}}',
            'id',
            'CASCADE'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        // drops foreign key for table `{{%posts}}`
        $this->dropForeignKey(
            '{{%fk-comments-post}}',
            '{{%comments}}'
        );

        // drops index for column `post`
        $this->dropIndex(
            '{{%idx-comments-post}}',
            '{{%comments}}'
        );

        // drops foreign key for table `{{%admin}}`
        $this->dropForeignKey(
            '{{%fk-comments-author}}',
            '{{%comments}}'
        );

        // drops index for column `author`
        $this->dropIndex(
            '{{%idx-comments-author}}',
            '{{%comments}}'
        );

        $this->dropTable('{{%comments}}');
    }
}
